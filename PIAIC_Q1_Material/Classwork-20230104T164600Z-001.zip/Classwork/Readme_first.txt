
1) Download the jupyter files in your system first
2) Copy and paste the files in your working folder
   (working folder is where you are currently running 
   your jupyter notebook)

